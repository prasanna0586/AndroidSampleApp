package com.sample;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class Sample
 */
@MultipartConfig
public class Sample extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sample() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		File file = new File("D:\\dev\\Sample\\sample\\image\\Prasanna.jpg");	 
		byte[] byteArray = Base64.encodeBase64(Files.readAllBytes(file.toPath()));
		String byteArrayString = new String(byteArray);
		System.out.println("byteArrayString " + byteArrayString);
        
		String descriptionFromServer = "This is a text from Server....... "
				+ "Android is a mobile operating system (OS) based on the Linux kernel and currently "
				+ "developed by Google. With a user interface based on direct manipulation, Android is designed "
				+ "primarily for touchscreen mobile devices such as smartphones and tablet computers, with "
				+ "specialized user interfaces for televisions (Android TV), cars (Android Auto), and wrist "
				+ "watches (Android Wear). The OS uses touch inputs that loosely correspond to real-world "
				+ "actions, like swiping, tapping, pinching, and reverse pinching to manipulate on-screen "
				+ "objects, and a virtual keyboard. Despite being primarily designed for touchscreen input, "
				+ "it also has been used in game consoles, digital cameras, regular PCs (e.g. the HP Slate 21) "
				+ "and other electronics. Android is the most widely used mobile OS and, as of 2013, the highest "
				+ "selling OS overall. Android devices sell more than Microsoft Windows, iOS, and Mac OS X devices "
				+ "combined, with sales in 2012, 2013 and 2014 close to the installed base of all PCs. As of "
				+ "July 2013 the Google Play store has had over one million Android applications published, "
				+ "and over 50 billion applications downloaded. A developer survey conducted in April–May 2013 "
				+ "found that 71% of mobile developers develop for Android. At Google I/O 2014, the company revealed "
				+ "that there were over one billion active monthly Android users, up from 538 million in June 2013. "
				+ "Android source code is released by Google under open source licenses, although most Android devices "
				+ "ultimately ship with a combination of open source and proprietary software, including proprietary "
				+ "software developed and licensed by Google. Initially developed by Android, Inc., which Google backed "
				+ "financially and later bought in 2005, Android was unveiled in 2007 along with the founding of the Open "
				+ "Handset Alliance—​a consortium of hardware, software, and telecommunication companies devoted to "
				+ "advancing open standards for mobile devices.[22] Android is popular with technology companies which "
				+ "require a ready-made, low-cost and customizable operating system for high-tech devices. Android open "
				+ "nature has encouraged a large community of developers and enthusiasts to use the open-source code as a "
				+ "foundation for community-driven projects, which add new features for advanced users or bring Android "
				+ "to devices which were officially released running other operating systems. The operating system success "
				+ "has made it a target for patent litigation as part of the so-called smartphone wars between technology "
				+ "companies.";
		
		JSONObject jsonObject = new JSONObject();
		PrintWriter writer = response.getWriter(); 
		try {
			jsonObject.put("description", descriptionFromServer);
			jsonObject.put("image", byteArrayString);
			writer.write(jsonObject.toString());
			
		} finally {
			writer.close();
		}
	}
}